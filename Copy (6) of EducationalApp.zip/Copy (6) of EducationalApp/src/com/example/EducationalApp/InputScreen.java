//optimise to check whether the "matching region" is longer or shorter than the BLOSUM matrix, to speed up running time

package com.example.EducationalApp;

import java.util.Random;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class InputScreen extends Activity
{

	Button Cmpr, Rand;
	EditText input1,input2;
	String sequence1="",sequence2="";
	int gap_penalty = -10; // gap penalty at the sides. (mid gap penalties are included in matrices)
	char amino_alphabet62[]= {'C', 'S', 'T', 'P', 'A', 'G', 'N', 'D', 'E', 'Q', 'H', 'R', 'K', 'M', 'I', 'L', 'V', 'F', 'Y', 'W', '-'/* "gap" */};
	char amino_alphabet45or80[]= {'A', 'R', 'N', 'D', 'C', 'Q', 'E', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V', 'B', 'J', 'Z', 'X', '-'};
	char DNA_alphabet[]= {'A', 'C', 'G', 'T', '-'};
	char RNA_alphabet[]= {'A', 'C', 'G', 'U', '-'};
	TextView display1, display2;
	Spinner Matrices;
	//String somevar="";
	int alignment = 0;
	
	int[][] Blosum45 = new int[][]
		 {{5, -2, -1, -2, -1, -1, -1,  0, -2, -1, -1, -1, -1, -2, -1,  1,  0, -2, -2,  0, -1, -1, -1, -1, -5},
		 {-2,  7,  0, -1, -3,  1,  0, -2,  0, -3, -2,  3, -1, -2, -2, -1, -1, -2, -1, -2, -1, -3,  1, -1, -5},
		 {-1,  0,  6,  2, -2,  0,  0,  0,  1, -2, -3,  0, -2, -2, -2,  1,  0, -4, -2, -3,  5, -3,  0, -1, -5},
		 {-2, -1,  2,  7, -3,  0,  2, -1,  0, -4, -3,  0, -3, -4, -1,  0, -1, -4, -2, -3,  6, -3,  1, -1, -5},
		 {-1, -3, -2, -3, 12, -3, -3, -3, -3, -3, -2, -3, -2, -2, -4, -1, -1, -5, -3, -1, -2, -2, -3, -1, -5},
		 {-1,  1,  0,  0, -3,  6,  2, -2,  1, -2, -2,  1,  0, -4, -1,  0, -1, -2, -1, -3,  0, -2,  4, -1, -5},
		 {-1,  0,  0,  2, -3,  2,  6, -2,  0, -3, -2,  1, -2, -3,  0,  0, -1, -3, -2, -3,  1, -3,  5, -1, -5},
		 { 0, -2,  0, -1, -3, -2, -2,  7, -2, -4, -3, -2, -2, -3, -2,  0, -2, -2, -3, -3, -1, -4, -2, -1, -5},
		 {-2,  0,  1,  0, -3,  1,  0, -2, 10, -3, -2, -1,  0, -2, -2, -1, -2, -3,  2, -3,  0, -2,  0, -1, -5},
		 {-1, -3, -2, -4, -3, -2, -3, -4, -3,  5,  2, -3,  2,  0, -2, -2, -1, -2,  0,  3, -3,  4, -3, -1, -5},
		 {-1, -2, -3, -3, -2, -2, -2, -3, -2,  2,  5, -3,  2,  1, -3, -3, -1, -2,  0,  1, -3,  4, -2, -1, -5},
		 {-1,  3,  0,  0, -3,  1,  1, -2, -1, -3, -3,  5, -1, -3, -1, -1, -1, -2, -1, -2,  0, -3,  1, -1, -5},
		 {-1, -1, -2, -3, -2,  0, -2, -2,  0,  2,  2, -1,  6,  0, -2, -2, -1, -2,  0,  1, -2,  2, -1, -1, -5},
		 {-2, -2, -2, -4, -2, -4, -3, -3, -2,  0,  1, -3,  0,  8, -3, -2, -1,  1,  3,  0, -3,  1, -3, -1, -5},
		 {-1, -2, -2, -1, -4, -1,  0, -2, -2, -2, -3, -1, -2, -3,  9, -1, -1, -3, -3, -3, -2, -3, -1, -1, -5},
		 { 1, -1,  1,  0, -1,  0,  0,  0, -1, -2, -3, -1, -2, -2, -1,  4,  2, -4, -2, -1,  0, -2,  0, -1, -5},
		 { 0, -1,  0, -1, -1, -1, -1, -2, -2, -1, -1, -1, -1, -1, -1,  2,  5, -3, -1,  0,  0, -1, -1, -1, -5},
		 {-2, -2, -4, -4, -5, -2, -3, -2, -3, -2, -2, -2, -2,  1, -3, -4, -3, 15,  3, -3, -4, -2, -2, -1, -5},
		 {-2, -1, -2, -2, -3, -1, -2, -3,  2,  0,  0, -1,  0,  3, -3, -2, -1,  3,  8, -1, -2,  0, -2, -1, -5},
		 { 0, -2, -3, -3, -1, -3, -3, -3, -3,  3,  1, -2,  1,  0, -3, -1,  0, -3, -1,  5, -3,  2, -3, -1, -5},
		 {-1, -1,  5,  6, -2,  0,  1, -1,  0, -3, -3,  0, -2, -3, -2,  0,  0, -4, -2, -3,  5, -3,  1, -1, -5},
		 {-1, -3, -3, -3, -2, -2, -3, -4, -2,  4,  4, -3,  2,  1, -3, -2, -1, -2,  0,  2, -3,  4, -2, -1, -5},
		 {-1,  1,  0,  1, -3,  4,  5, -2,  0, -3, -2,  1, -1, -3, -1,  0, -1, -2, -2, -3,  1, -2,  5, -1, -5},
		 {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -5},
		 {-5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5,  1}};
	int[][] Blosum62 = new int[][]
			{{9, -1,    -1,    -3,    0,    -3,    -3,    -3,    -4,    -3,    -3,    -3,    -3,    -1,    -1,    -1,    -1,    -2,    -2,    -2, -1},
            {-1, 4,    1,    -1,    1,    0,    1,    0,    0,    0,    -1,    -1,    0,    -1,    -2,    -2,    -2,    -2,    -2,    -3, -1},
            {-1, 1,    4,    1,    -1,    1,    0,    -1,    0,    0,    0,    -1,    0,    -1,    -2,    -2,    -2,    -2,    -2,    -3, -1},
            {-3, -1,    1,    7,    -1,    -2,    -1,    -1,    -1,    -1,    -2,    -2,    -1,    -2,    -3,    -3,    -2,    -4,    -3,    -4, -1},
            {0,    1,    -1,    -1,    4,    0,    -1,    -2,    -1,    -1,    -2,    -1,    -1,    -1,    -1,    -1,    -2,    -2,    -2,    -3, -1},
            {-3, 0,    1, -2,    0,    6,    -2,    -1,    -2,    -2,    -2,    -2,    -2,    -3,    -4,    -4,    0,    -3,    -3,    -2, -1},
            {-3, 1,    0,    -2,    -2,    0,    6,    1,    0,    0,    -1,    0,    0,    -2,    -3,    -3,    -3,    -3,    -2,    -4, -1},
            {-3, 0,    -1,    -1,    -2,    -1,    1,    6,    2,    0,    -1,    -2,    -1,    -3,    -3,    -4,    -3,    -3,    -3,    -4, -1},
            {-4, 0,    0,    -1,    -1,    -2,    0,    2,    5,    2,    0,    0,    1,    -2,    -3,    -3,    -3,    -3,    -2,    -3, -1},
            {-3, 0,    0,    -1,    -1,    -2,    0,    0,    2,    5,    0,    1,    1,    0,    -3,    -2,    -2,    -3,    -1,    -2, -1},
            {-3, -1, 0,    -2,    -2,    -2,    1,    1,    0,    0,    8,    0,    -1,    -2,    -3,    -3,    -2,    -1,    2,    -2, -1},
            {-3, -1, -1,    -2,    -1,    -2,    0,    -2,    0,    1,    0,    5,    2,    -1,    -3,    -2,    -3,    -3,    -2,    -3, -1},
            {-3, 0,    0, -1,    -1,    -2,    0,    -1,    1,    1,    -1,    2,    5,    -1,    -3,    -2,    -3,    -3,    -2,    -3, -1},
            {1, -1,    -1,    -2,    -1,    -3,    -2,    -3,    -2,    0,    -2,    -1,    -1,    5,    1,    2,    -2,    0,    -1,    -1, -1},
            {-1, -2, -2,    -3,    -1,    -4,    -3,    -3,    -3,    -3,    -3,    -3,    -3,    1,    4,    2,    1,    0,    -1,    -3, -1},
            {-1, -2, -2,    -3,    -1,    -4,    -3,    -4,    -3,    -2,    -3,    -2,    -2,    2,    2,    4,    3,    0,    -1,    -2, -1},
            {-1, -2, -2,    -2,    0,    -3,    -3,    -3,    -2,    -2,    -3,    -3,    -2,    1,    3,    1,    4,    -1,    -1,    -3, -1},
            {-2, -2, -2,    -4,    -2,    -3,    -3,    -3,    -3,    -3,    -1,    -3,    -3,    0,    0,    0,    -1,    6,    3,    1, -1},
            {-2, -2, -2,    -3,    -2,    -3,    -2,    -3,    -2,    -1,    2,    -2,    -2,    -1,    -1,    -1,    -1,    3,    7,    2, -1},
            {-2, -3, -3,    -4,    -3,    -2,    -4,    -4,    -3,    -2,    -2,    -3,    -3,    -1,    -3,    -2,    -3,    1,    2,    11, -1},
            {-1, -1, -1,    -1,    -1,   -1, -1,  -1,  -1,   -1,   -1,   -1,   -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1, 1}};
			/*
			{{9, -1,	-1,	-3,	0,	-3,	-3,	-3,	-4,	-3,	-3,	-3,	-3,	-1,	-1,	-1,	-1,	-2,	-2,	-2},
			{-1, 4,	1,	-1,	1,	0,	1,	0,	0,	0,	-1,	-1,	0,	-1,	-2,	-2,	-2,	-2,	-2,	-3},
			{-1, 1,	4,	1,	-1,	1,	0,	1,	0,	0,	0,	-1,	0,	-1,	-2,	-2,	-2,	-2,	-2,	-3},
			{-3, -1,	1,	7,	-1,	-2,	-1,	-1,	-1,	-1,	-2,	-2,	-1,	-2,	-3,	-3,	-2,	-4,	-3,	-4},
			{0,	1,	-1,	-1,	4,	0,	-1,	-2,	-1,	-1,	-2,	-1,	-1,	-1,	-1,	-1,	-2,	-2,	-2,	-3},
			{-3, 0,	1, -2,	0,	6,	-2,	-1,	-2,	-2,	-2,	-2,	-2,	-3,	-4,	-4,	0,	-3,	-3,	-2},
			{-3, 1,	0,	-2,	-2,	0,	6,	1,	0,	0,	-1,	0,	0,	-2,	-3,	-3,	-3,	-3,	-2,	-4},
			{-3, 0,	1,	-1,	-2,	-1,	1,	6,	2,	0,	-1,	-2,	-1,	-3,	-3,	-4,	-3,	-3,	-3,	-4},
			{-4, 0,	0,	-1,	-1,	-2,	0,	2,	5,	2,	0,	0,	1,	-2,	-3,	-3,	-3,	-3,	-2,	-3},
			{-3, 0,	0,	-1,	-1,	-2,	0,	0,	2,	5,	0,	1,	1,	0,	-3,	-2,	-2,	-3,	-1,	-2},
			{-3, -1, 0,	-2,	-2,	-2,	1,	1,	0,	0,	8,	0,	-1,	-2,	-3,	-3,	-2,	-1,	2,	-2},
			{-3, -1, -1,	-2,	-1,	-2,	0,	-2,	0,	1,	0,	5,	2,	-1,	-3,	-2,	-3,	-3,	-2,	-3},
			{-3, 0,	0, -1,	-1,	-2,	0,	-1,	1,	1,	-1,	2,	5,	-1,	-3,	-2,	-3,	-3,	-2,	-3},
			{1, -1,	-1,	-2,	-1,	-3,	-2,	-3,	-2,	0,	-2,	-1,	-1,	5,	1,	2,	-2,	0,	-1,	-1},
			{-1, -2, -2,	-3,	-1,	-4,	-3,	-3,	-3,	-3,	-3,	-3,	-3,	1,	4,	2,	1,	0,	-1,	-3},
			{-1, -2, -2,	-3,	-1,	-4,	-3,	-4,	-3,	-2,	-3,	-2,	-2,	2,	2,	4,	3,	0,	-1,	-2},
			{-1, -2, -2,	-2,	0,	-3,	-3,	-3,	-2,	-2,	-3,	-3,	-2,	1,	3,	1,	4,	-1,	-1,	-3},
			{-2, -2, -2,	-4,	-2,	-3,	-3,	-3,	-3,	-3,	-1,	-3,	-3,	0,	0,	0,	-1,	6,	3,	1},
			{-2, -2, -2,	-3,	-2,	-3,	-2,	-3,	-2,	-1,	2,	-2,	-2,	-1,	-1,	-1,	-1,	3,	7,	2},
			{-2, -3, -3,	-4,	-3,	-2,	-4,	-4,	-3,	-2,	-2,	-3,	-3,	-1,	-3,	-2,	-3,	1,	2,	11}};
	*/
	int[][] Blosum80 = new int[][]
			     {{5, -2, -2, -2, -1, -1, -1,  0, -2, -2, -2, -1, -1, -3, -1,  1,  0, -3, -2,  0, -2, -2, -1, -1, -6},
		     	 {-2,  6, -1, -2, -4,  1, -1, -3,  0, -3, -3,  2, -2, -4, -2, -1, -1, -4, -3, -3, -1, -3,  0, -1, -6},
		     	 {-2, -1,  6,  1, -3,  0, -1, -1,  0, -4, -4,  0, -3, -4, -3,  0,  0, -4, -3, -4,  5, -4,  0, -1, -6},
				 {-2, -2,  1,  6, -4, -1,  1, -2, -2, -4, -5, -1, -4, -4, -2, -1, -1, -6, -4, -4,  5, -5,  1, -1, -6},
				 {-1, -4, -3, -4,  9, -4, -5, -4, -4, -2, -2, -4, -2, -3, -4, -2, -1, -3, -3, -1, -4, -2, -4, -1, -6},
				 {-1,  1,  0, -1, -4,  6,  2, -2,  1, -3, -3,  1,  0, -4, -2,  0, -1, -3, -2, -3,  0, -3,  4, -1, -6},
				 {-1, -1, -1,  1, -5,  2,  6, -3,  0, -4, -4,  1, -2, -4, -2,  0, -1, -4, -3, -3,  1, -4,  5, -1, -6},
				 { 0, -3, -1, -2, -4, -2, -3,  6, -3, -5, -4, -2, -4, -4, -3, -1, -2, -4, -4, -4, -1, -5, -3, -1, -6},
				 {-2,  0,  0, -2, -4,  1,  0, -3,  8, -4, -3, -1, -2, -2, -3, -1, -2, -3,  2, -4, -1, -4,  0, -1, -6},
				 {-2, -3, -4, -4, -2, -3, -4, -5, -4,  5,  1, -3,  1, -1, -4, -3, -1, -3, -2,  3, -4,  3, -4, -1, -6},
				 {-2, -3, -4, -5, -2, -3, -4, -4, -3,  1,  4, -3,  2,  0, -3, -3, -2, -2, -2,  1, -4,  3, -3, -1, -6},
				 {-1,  2,  0, -1, -4,  1,  1, -2, -1, -3, -3,  5, -2, -4, -1, -1, -1, -4, -3, -3, -1, -3,  1, -1, -6},
				 {-1, -2, -3, -4, -2,  0, -2, -4, -2,  1,  2, -2,  6,  0, -3, -2, -1, -2, -2,  1, -3,  2, -1, -1, -6},
				 {-3, -4, -4, -4, -3, -4, -4, -4, -2, -1,  0, -4,  0,  6, -4, -3, -2,  0,  3, -1, -4,  0, -4, -1, -6},
				 {-1, -2, -3, -2, -4, -2, -2, -3, -3, -4, -3, -1, -3, -4,  8, -1, -2, -5, -4, -3, -2, -4, -2, -1, -6},
				 { 1, -1,  0, -1, -2,  0,  0, -1, -1, -3, -3, -1, -2, -3, -1,  5,  1, -4, -2, -2,  0, -3,  0, -1, -6},
				 { 0, -1,  0, -1, -1, -1, -1, -2, -2, -1, -2, -1, -1, -2, -2,  1,  5, -4, -2,  0, -1, -1, -1, -1, -6},
				 {-3, -4, -4, -6, -3, -3, -4, -4, -3, -3, -2, -4, -2,  0, -5, -4, -4, 11,  2, -3, -5, -3, -3, -1, -6},
				 {-2, -3, -3, -4, -3, -2, -3, -4,  2, -2, -2, -3, -2,  3, -4, -2, -2,  2,  7, -2, -3, -2, -3, -1, -6},
				 { 0, -3, -4, -4, -1, -3, -3, -4, -4,  3,  1, -3,  1, -1, -3, -2,  0, -3, -2,  4, -4,  2, -3, -1, -6},
				 {-2, -1,  5,  5, -4,  0,  1, -1, -1, -4, -4, -1, -3, -4, -2,  0, -1, -5, -3, -4,  5, -4,  0, -1, -6},
				 {-2, -3, -4, -5, -2, -3, -4, -5, -4,  3,  3, -3,  2,  0, -4, -3, -1, -3, -2,  2, -4,  3, -3, -1, -6},
				 {-1,  0,  0,  1, -4,  4,  5, -3,  0, -4, -3,  1, -1, -4, -2,  0, -1, -3, -3, -3,  0, -3,  5, -1, -6},
				 {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -6},
				 {-6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6,  1}};	

	int[][] DNAmat = new int[][]
	{{7, -1,	-8,	-10, -1},
	{-1,	7,	-9,	-8, -1},
	{-8,	-9,	7,	-1, -1},
	{-10,	-8,	-1,	7, -1},
	{-1,	-1,	-1,-1, -1}};
	
	int[][] RNAmat = new int[][]
			{{7, -1,	-8,	-10, -1},
			{-1,	7,	-9,	-8, -1},
			{-8,	-9,	7,	-1, -1},
			{-10,	-8,	-1,	7, -1},
			{-1,	-1,	-1,-1, -1}};

	
	
	char[] currentChar = amino_alphabet62;
	int[][] currentMatrix = Blosum62;
	
	private Handler messagepass = new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.inputscreen);
		
		initialiseC();
		
		Cmpr.setOnClickListener
		(
				new View.OnClickListener() 
		{
			
			public void onClick(View v) 
			{
				sequence1=input1.getText().toString().toUpperCase();
				sequence2=input2.getText().toString().toUpperCase();
				alignment = 0;
				
				
				try{
        			Class ourClass= Class.forName("com.example.EducationalApp.Sequenceviews");
        			Intent ourIntent= new Intent(InputScreen.this,ourClass);
        			String[] seqarray = new String[2];
        			seqarray[0]=sequence1;
        			seqarray[1]=sequence2;
        			ourIntent.putExtra("strings",seqarray);
        			//startActivity(ourIntent);
        		}catch(ClassNotFoundException e){
        			e.printStackTrace();
        		}
			}
			
		}); // End Cmpr OnClickListener
		
		Rand.setOnClickListener
		(
				new View.OnClickListener() 
		{
			
			public void onClick(View v) 
			{
				int slength = 10; // how long the random sequence will be
				
				
				String seq1="";
				StringBuffer sb= new StringBuffer(); // couldn't figure out how to clear the buffer.
				
				Random rand= new Random();
				char newchar;
				int ind=0;
				int mlength = (currentChar.toString()).length(); // mlength = the length of the character array containing all the "character" (proteins) in the matrix
				for(int q=0;q<slength;q++){
					ind=rand.nextInt(mlength);
					newchar=currentChar[ind];
					sb.append(newchar);
				}
				seq1=sb.toString();
				input1.setText(""+ seq1);
				sb.append("\n");
				for(int q=0;q<slength;q++){
					ind=rand.nextInt(mlength);
					newchar=currentChar[ind];
					sb.append(newchar);
					
				}
				
				seq1=sb.toString();
				input2.setText(""+ seq1);
				
			}
			
		}); // End Rand OnClickListener
		
		
		
		
		
		Matrices.setOnItemSelectedListener(new MyOnItemSelectedListener());
		
	} // Overwrite onCreate
	

	
	public class MyOnItemSelectedListener implements OnItemSelectedListener 
	{

	    public void onItemSelected(AdapterView<?> parent,View view, int pos, long id) 
	    {
	    	Toast.makeText(parent.getContext(), parent.getItemAtPosition(pos).toString()+ " selected.", Toast.LENGTH_LONG).show();
	    	switch(pos)
	    	{
		    case 0:
		    	currentChar = amino_alphabet45or80;
		    	currentMatrix = Blosum45;
		    	break;
		    case 1:
		    	currentChar = amino_alphabet62;
		    	currentMatrix = Blosum62;
		    	break;
		    case 2:
		    	currentChar = amino_alphabet45or80;
		    	currentMatrix = Blosum80;
		    	break;	
		    case 3:
		    	currentChar = DNA_alphabet;
		    	currentMatrix = DNAmat;
		    	break;	
		    case 4:
		    	currentChar = RNA_alphabet;
		    	currentMatrix = RNAmat;
		    	break;	
	    	}
	    }
	    
	    public void onNothingSelected(AdapterView parent) 
	    {
	      // Do nothing.
	    }

	}
	
	public void onNothingSelected(AdapterView parent) 
	{
	// Do nothing.
	}
	
	
	
	private void AlignStrings() 
	{
		
		
	}

	private void initialiseC() 
	{
		Rand=(Button) findViewById(R.id.bRandom_in);
		Cmpr=(Button) findViewById(R.id.bCompare_in);
		input1=(EditText) findViewById(R.id.Sequence1_in);
		input2=(EditText) findViewById(R.id.Sequence2_in);
		Matrices= (Spinner) findViewById(R.id.spinner1_in);
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.BLOSUMS_ARRAY, android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		Matrices.setAdapter(adapter);
	}
} // End CompareSequenceActivity

		