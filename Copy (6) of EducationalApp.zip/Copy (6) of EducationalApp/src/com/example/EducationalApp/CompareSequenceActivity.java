//optimise to check whether the "matching region" is longer or shorter than the BLOSUM matrix, to speed up running time

package com.example.EducationalApp;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class CompareSequenceActivity extends Activity
{

	Button Cmpr, left, right;
	EditText input1,input2;
	char sequence1[] = {},sequence2[] = {};
	int gap_penalty = -10; // gap penalty at the sides. (mid gap penalties are included in matrices)
	char amino_alphabet62[]= {'C', 'S', 'T', 'P', 'A', 'G', 'N', 'D', 'E', 'Q', 'H', 'R', 'K', 'M', 'I', 'L', 'V', 'F', 'Y', 'W', '-'/* "gap" */};
	char amino_alphabet45or80[]= {'A', 'R', 'N', 'D', 'C', 'Q', 'E', 'G', 'H', 'I', 'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V', 'B', 'J', 'Z', 'X', '-'};
	char DNA_alphabet[]= {'A', 'C', 'G', 'T', '-'};
	char RNA_alphabet[]= {'A', 'C', 'G', 'U', '-'};
	TextView display1, display2, align_comparison, tvSeq1, tvSeq2, RES;
	Spinner Matrices;
	//String somevar="";
	int alignment = 0;
	
	int[][] Blosum45 = new int[][]
		 {{5, -2, -1, -2, -1, -1, -1,  0, -2, -1, -1, -1, -1, -2, -1,  1,  0, -2, -2,  0, -1, -1, -1, -1, -5},
		 {-2,  7,  0, -1, -3,  1,  0, -2,  0, -3, -2,  3, -1, -2, -2, -1, -1, -2, -1, -2, -1, -3,  1, -1, -5},
		 {-1,  0,  6,  2, -2,  0,  0,  0,  1, -2, -3,  0, -2, -2, -2,  1,  0, -4, -2, -3,  5, -3,  0, -1, -5},
		 {-2, -1,  2,  7, -3,  0,  2, -1,  0, -4, -3,  0, -3, -4, -1,  0, -1, -4, -2, -3,  6, -3,  1, -1, -5},
		 {-1, -3, -2, -3, 12, -3, -3, -3, -3, -3, -2, -3, -2, -2, -4, -1, -1, -5, -3, -1, -2, -2, -3, -1, -5},
		 {-1,  1,  0,  0, -3,  6,  2, -2,  1, -2, -2,  1,  0, -4, -1,  0, -1, -2, -1, -3,  0, -2,  4, -1, -5},
		 {-1,  0,  0,  2, -3,  2,  6, -2,  0, -3, -2,  1, -2, -3,  0,  0, -1, -3, -2, -3,  1, -3,  5, -1, -5},
		 { 0, -2,  0, -1, -3, -2, -2,  7, -2, -4, -3, -2, -2, -3, -2,  0, -2, -2, -3, -3, -1, -4, -2, -1, -5},
		 {-2,  0,  1,  0, -3,  1,  0, -2, 10, -3, -2, -1,  0, -2, -2, -1, -2, -3,  2, -3,  0, -2,  0, -1, -5},
		 {-1, -3, -2, -4, -3, -2, -3, -4, -3,  5,  2, -3,  2,  0, -2, -2, -1, -2,  0,  3, -3,  4, -3, -1, -5},
		 {-1, -2, -3, -3, -2, -2, -2, -3, -2,  2,  5, -3,  2,  1, -3, -3, -1, -2,  0,  1, -3,  4, -2, -1, -5},
		 {-1,  3,  0,  0, -3,  1,  1, -2, -1, -3, -3,  5, -1, -3, -1, -1, -1, -2, -1, -2,  0, -3,  1, -1, -5},
		 {-1, -1, -2, -3, -2,  0, -2, -2,  0,  2,  2, -1,  6,  0, -2, -2, -1, -2,  0,  1, -2,  2, -1, -1, -5},
		 {-2, -2, -2, -4, -2, -4, -3, -3, -2,  0,  1, -3,  0,  8, -3, -2, -1,  1,  3,  0, -3,  1, -3, -1, -5},
		 {-1, -2, -2, -1, -4, -1,  0, -2, -2, -2, -3, -1, -2, -3,  9, -1, -1, -3, -3, -3, -2, -3, -1, -1, -5},
		 { 1, -1,  1,  0, -1,  0,  0,  0, -1, -2, -3, -1, -2, -2, -1,  4,  2, -4, -2, -1,  0, -2,  0, -1, -5},
		 { 0, -1,  0, -1, -1, -1, -1, -2, -2, -1, -1, -1, -1, -1, -1,  2,  5, -3, -1,  0,  0, -1, -1, -1, -5},
		 {-2, -2, -4, -4, -5, -2, -3, -2, -3, -2, -2, -2, -2,  1, -3, -4, -3, 15,  3, -3, -4, -2, -2, -1, -5},
		 {-2, -1, -2, -2, -3, -1, -2, -3,  2,  0,  0, -1,  0,  3, -3, -2, -1,  3,  8, -1, -2,  0, -2, -1, -5},
		 { 0, -2, -3, -3, -1, -3, -3, -3, -3,  3,  1, -2,  1,  0, -3, -1,  0, -3, -1,  5, -3,  2, -3, -1, -5},
		 {-1, -1,  5,  6, -2,  0,  1, -1,  0, -3, -3,  0, -2, -3, -2,  0,  0, -4, -2, -3,  5, -3,  1, -1, -5},
		 {-1, -3, -3, -3, -2, -2, -3, -4, -2,  4,  4, -3,  2,  1, -3, -2, -1, -2,  0,  2, -3,  4, -2, -1, -5},
		 {-1,  1,  0,  1, -3,  4,  5, -2,  0, -3, -2,  1, -1, -3, -1,  0, -1, -2, -2, -3,  1, -2,  5, -1, -5},
		 {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -5},
		 {-5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5,  1}};
	int[][] Blosum62 = new int[][]
			{{9, -1,    -1,    -3,    0,    -3,    -3,    -3,    -4,    -3,    -3,    -3,    -3,    -1,    -1,    -1,    -1,    -2,    -2,    -2, -1},
            {-1, 4,    1,    -1,    1,    0,    1,    0,    0,    0,    -1,    -1,    0,    -1,    -2,    -2,    -2,    -2,    -2,    -3, -1},
            {-1, 1,    4,    1,    -1,    1,    0,    -1,    0,    0,    0,    -1,    0,    -1,    -2,    -2,    -2,    -2,    -2,    -3, -1},
            {-3, -1,    1,    7,    -1,    -2,    -1,    -1,    -1,    -1,    -2,    -2,    -1,    -2,    -3,    -3,    -2,    -4,    -3,    -4, -1},
            {0,    1,    -1,    -1,    4,    0,    -1,    -2,    -1,    -1,    -2,    -1,    -1,    -1,    -1,    -1,    -2,    -2,    -2,    -3, -1},
            {-3, 0,    1, -2,    0,    6,    -2,    -1,    -2,    -2,    -2,    -2,    -2,    -3,    -4,    -4,    0,    -3,    -3,    -2, -1},
            {-3, 1,    0,    -2,    -2,    0,    6,    1,    0,    0,    -1,    0,    0,    -2,    -3,    -3,    -3,    -3,    -2,    -4, -1},
            {-3, 0,    -1,    -1,    -2,    -1,    1,    6,    2,    0,    -1,    -2,    -1,    -3,    -3,    -4,    -3,    -3,    -3,    -4, -1},
            {-4, 0,    0,    -1,    -1,    -2,    0,    2,    5,    2,    0,    0,    1,    -2,    -3,    -3,    -3,    -3,    -2,    -3, -1},
            {-3, 0,    0,    -1,    -1,    -2,    0,    0,    2,    5,    0,    1,    1,    0,    -3,    -2,    -2,    -3,    -1,    -2, -1},
            {-3, -1, 0,    -2,    -2,    -2,    1,    1,    0,    0,    8,    0,    -1,    -2,    -3,    -3,    -2,    -1,    2,    -2, -1},
            {-3, -1, -1,    -2,    -1,    -2,    0,    -2,    0,    1,    0,    5,    2,    -1,    -3,    -2,    -3,    -3,    -2,    -3, -1},
            {-3, 0,    0, -1,    -1,    -2,    0,    -1,    1,    1,    -1,    2,    5,    -1,    -3,    -2,    -3,    -3,    -2,    -3, -1},
            {1, -1,    -1,    -2,    -1,    -3,    -2,    -3,    -2,    0,    -2,    -1,    -1,    5,    1,    2,    -2,    0,    -1,    -1, -1},
            {-1, -2, -2,    -3,    -1,    -4,    -3,    -3,    -3,    -3,    -3,    -3,    -3,    1,    4,    2,    1,    0,    -1,    -3, -1},
            {-1, -2, -2,    -3,    -1,    -4,    -3,    -4,    -3,    -2,    -3,    -2,    -2,    2,    2,    4,    3,    0,    -1,    -2, -1},
            {-1, -2, -2,    -2,    0,    -3,    -3,    -3,    -2,    -2,    -3,    -3,    -2,    1,    3,    1,    4,    -1,    -1,    -3, -1},
            {-2, -2, -2,    -4,    -2,    -3,    -3,    -3,    -3,    -3,    -1,    -3,    -3,    0,    0,    0,    -1,    6,    3,    1, -1},
            {-2, -2, -2,    -3,    -2,    -3,    -2,    -3,    -2,    -1,    2,    -2,    -2,    -1,    -1,    -1,    -1,    3,    7,    2, -1},
            {-2, -3, -3,    -4,    -3,    -2,    -4,    -4,    -3,    -2,    -2,    -3,    -3,    -1,    -3,    -2,    -3,    1,    2,    11, -1},
            {-1, -1, -1,    -1,    -1,   -1, -1,  -1,  -1,   -1,   -1,   -1,   -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1, 1}};
			/*
			{{9, -1,	-1,	-3,	0,	-3,	-3,	-3,	-4,	-3,	-3,	-3,	-3,	-1,	-1,	-1,	-1,	-2,	-2,	-2},
			{-1, 4,	1,	-1,	1,	0,	1,	0,	0,	0,	-1,	-1,	0,	-1,	-2,	-2,	-2,	-2,	-2,	-3},
			{-1, 1,	4,	1,	-1,	1,	0,	1,	0,	0,	0,	-1,	0,	-1,	-2,	-2,	-2,	-2,	-2,	-3},
			{-3, -1,	1,	7,	-1,	-2,	-1,	-1,	-1,	-1,	-2,	-2,	-1,	-2,	-3,	-3,	-2,	-4,	-3,	-4},
			{0,	1,	-1,	-1,	4,	0,	-1,	-2,	-1,	-1,	-2,	-1,	-1,	-1,	-1,	-1,	-2,	-2,	-2,	-3},
			{-3, 0,	1, -2,	0,	6,	-2,	-1,	-2,	-2,	-2,	-2,	-2,	-3,	-4,	-4,	0,	-3,	-3,	-2},
			{-3, 1,	0,	-2,	-2,	0,	6,	1,	0,	0,	-1,	0,	0,	-2,	-3,	-3,	-3,	-3,	-2,	-4},
			{-3, 0,	1,	-1,	-2,	-1,	1,	6,	2,	0,	-1,	-2,	-1,	-3,	-3,	-4,	-3,	-3,	-3,	-4},
			{-4, 0,	0,	-1,	-1,	-2,	0,	2,	5,	2,	0,	0,	1,	-2,	-3,	-3,	-3,	-3,	-2,	-3},
			{-3, 0,	0,	-1,	-1,	-2,	0,	0,	2,	5,	0,	1,	1,	0,	-3,	-2,	-2,	-3,	-1,	-2},
			{-3, -1, 0,	-2,	-2,	-2,	1,	1,	0,	0,	8,	0,	-1,	-2,	-3,	-3,	-2,	-1,	2,	-2},
			{-3, -1, -1,	-2,	-1,	-2,	0,	-2,	0,	1,	0,	5,	2,	-1,	-3,	-2,	-3,	-3,	-2,	-3},
			{-3, 0,	0, -1,	-1,	-2,	0,	-1,	1,	1,	-1,	2,	5,	-1,	-3,	-2,	-3,	-3,	-2,	-3},
			{1, -1,	-1,	-2,	-1,	-3,	-2,	-3,	-2,	0,	-2,	-1,	-1,	5,	1,	2,	-2,	0,	-1,	-1},
			{-1, -2, -2,	-3,	-1,	-4,	-3,	-3,	-3,	-3,	-3,	-3,	-3,	1,	4,	2,	1,	0,	-1,	-3},
			{-1, -2, -2,	-3,	-1,	-4,	-3,	-4,	-3,	-2,	-3,	-2,	-2,	2,	2,	4,	3,	0,	-1,	-2},
			{-1, -2, -2,	-2,	0,	-3,	-3,	-3,	-2,	-2,	-3,	-3,	-2,	1,	3,	1,	4,	-1,	-1,	-3},
			{-2, -2, -2,	-4,	-2,	-3,	-3,	-3,	-3,	-3,	-1,	-3,	-3,	0,	0,	0,	-1,	6,	3,	1},
			{-2, -2, -2,	-3,	-2,	-3,	-2,	-3,	-2,	-1,	2,	-2,	-2,	-1,	-1,	-1,	-1,	3,	7,	2},
			{-2, -3, -3,	-4,	-3,	-2,	-4,	-4,	-3,	-2,	-2,	-3,	-3,	-1,	-3,	-2,	-3,	1,	2,	11}};
	*/
	int[][] Blosum80 = new int[][]
			     {{5, -2, -2, -2, -1, -1, -1,  0, -2, -2, -2, -1, -1, -3, -1,  1,  0, -3, -2,  0, -2, -2, -1, -1, -6},
		     	 {-2,  6, -1, -2, -4,  1, -1, -3,  0, -3, -3,  2, -2, -4, -2, -1, -1, -4, -3, -3, -1, -3,  0, -1, -6},
		     	 {-2, -1,  6,  1, -3,  0, -1, -1,  0, -4, -4,  0, -3, -4, -3,  0,  0, -4, -3, -4,  5, -4,  0, -1, -6},
				 {-2, -2,  1,  6, -4, -1,  1, -2, -2, -4, -5, -1, -4, -4, -2, -1, -1, -6, -4, -4,  5, -5,  1, -1, -6},
				 {-1, -4, -3, -4,  9, -4, -5, -4, -4, -2, -2, -4, -2, -3, -4, -2, -1, -3, -3, -1, -4, -2, -4, -1, -6},
				 {-1,  1,  0, -1, -4,  6,  2, -2,  1, -3, -3,  1,  0, -4, -2,  0, -1, -3, -2, -3,  0, -3,  4, -1, -6},
				 {-1, -1, -1,  1, -5,  2,  6, -3,  0, -4, -4,  1, -2, -4, -2,  0, -1, -4, -3, -3,  1, -4,  5, -1, -6},
				 { 0, -3, -1, -2, -4, -2, -3,  6, -3, -5, -4, -2, -4, -4, -3, -1, -2, -4, -4, -4, -1, -5, -3, -1, -6},
				 {-2,  0,  0, -2, -4,  1,  0, -3,  8, -4, -3, -1, -2, -2, -3, -1, -2, -3,  2, -4, -1, -4,  0, -1, -6},
				 {-2, -3, -4, -4, -2, -3, -4, -5, -4,  5,  1, -3,  1, -1, -4, -3, -1, -3, -2,  3, -4,  3, -4, -1, -6},
				 {-2, -3, -4, -5, -2, -3, -4, -4, -3,  1,  4, -3,  2,  0, -3, -3, -2, -2, -2,  1, -4,  3, -3, -1, -6},
				 {-1,  2,  0, -1, -4,  1,  1, -2, -1, -3, -3,  5, -2, -4, -1, -1, -1, -4, -3, -3, -1, -3,  1, -1, -6},
				 {-1, -2, -3, -4, -2,  0, -2, -4, -2,  1,  2, -2,  6,  0, -3, -2, -1, -2, -2,  1, -3,  2, -1, -1, -6},
				 {-3, -4, -4, -4, -3, -4, -4, -4, -2, -1,  0, -4,  0,  6, -4, -3, -2,  0,  3, -1, -4,  0, -4, -1, -6},
				 {-1, -2, -3, -2, -4, -2, -2, -3, -3, -4, -3, -1, -3, -4,  8, -1, -2, -5, -4, -3, -2, -4, -2, -1, -6},
				 { 1, -1,  0, -1, -2,  0,  0, -1, -1, -3, -3, -1, -2, -3, -1,  5,  1, -4, -2, -2,  0, -3,  0, -1, -6},
				 { 0, -1,  0, -1, -1, -1, -1, -2, -2, -1, -2, -1, -1, -2, -2,  1,  5, -4, -2,  0, -1, -1, -1, -1, -6},
				 {-3, -4, -4, -6, -3, -3, -4, -4, -3, -3, -2, -4, -2,  0, -5, -4, -4, 11,  2, -3, -5, -3, -3, -1, -6},
				 {-2, -3, -3, -4, -3, -2, -3, -4,  2, -2, -2, -3, -2,  3, -4, -2, -2,  2,  7, -2, -3, -2, -3, -1, -6},
				 { 0, -3, -4, -4, -1, -3, -3, -4, -4,  3,  1, -3,  1, -1, -3, -2,  0, -3, -2,  4, -4,  2, -3, -1, -6},
				 {-2, -1,  5,  5, -4,  0,  1, -1, -1, -4, -4, -1, -3, -4, -2,  0, -1, -5, -3, -4,  5, -4,  0, -1, -6},
				 {-2, -3, -4, -5, -2, -3, -4, -5, -4,  3,  3, -3,  2,  0, -4, -3, -1, -3, -2,  2, -4,  3, -3, -1, -6},
				 {-1,  0,  0,  1, -4,  4,  5, -3,  0, -4, -3,  1, -1, -4, -2,  0, -1, -3, -3, -3,  0, -3,  5, -1, -6},
				 {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -6},
				 {-6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6,  1}};	

	int[][] DNAmat = new int[][]
	{{7, -1,	-8,	-10, -1},
	{-1,	7,	-9,	-8, -1},
	{-8,	-9,	7,	-1, -1},
	{-10,	-8,	-1,	7, -1},
	{-1,	-1,	-1,-1, -1}};
	
	int[][] RNAmat = new int[][]
			{{7, -1,	-8,	-10, -1},
			{-1,	7,	-9,	-8, -1},
			{-8,	-9,	7,	-1, -1},
			{-10,	-8,	-1,	7, -1},
			{-1,	-1,	-1,-1, -1}};

	
	
	char[] currentChar = amino_alphabet62;
	int[][] currentMatrix = Blosum62;
	
	private Handler messagepass = new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.comparisonscreen);
		
		initialiseC();
		
		Cmpr.setOnClickListener
		(
				new View.OnClickListener() 
		{
			
			public void onClick(View v) 
			{
				align_comparison.setText("COMPARE");
				// TODO Auto-generated method stub
				//seq1=;
				//seq2=;
				sequence1=input1.getText().toString().toUpperCase().toCharArray();
				sequence2=input2.getText().toString().toUpperCase().toCharArray();
				alignment = 0;
				new Thread
				(
						new Runnable()
				{
					//@Override
					public void run() 
					{	
						final String somevar = CompSeq(currentChar,currentMatrix); // !!!!!!!! HMMM !!!!!!!!!
						messagepass.post (new Runnable ()
						{
				            //@Override
				            public void run() 
				            {
				            	align_comparison.setText(somevar);
				            }
				         });
					}
				}).start();

				DispSeq();
				
			}
			
		}); // End Cmpr OnClickListener
		
		Matrices.setOnItemSelectedListener(new MyOnItemSelectedListener());
		
		left.setOnClickListener
		(
				new View.OnClickListener() 
		{
			public void onClick(View v) 
			{
				
				if (alignment > -sequence2.length+1) // check that it's not one out, but shouldn't be :/ 
				{
					align_comparison.setText("LEFT");
					alignment--;
					//CompSeq(currentChar,currentMatrix); // !!!!!!!! HMMM !!!!!!!!!
					new Thread
					(
							new Runnable()
					{
						//@Override
						public void run() 
						{	
							final String somevar = CompSeq(currentChar,currentMatrix); // !!!!!!!! HMMM !!!!!!!!!
							messagepass.post (new Runnable ()
							{
					            //@Override
					            public void run() 
					            {
					            	align_comparison.setText(somevar);
					            }
					         });
						}
					}).start();
					
					DispSeq();
					
				}
				
			}
		});// End left OnClickListener
		
		right.setOnClickListener
		(
				new View.OnClickListener() 
		{
			public void onClick(View v) 
			{
				if (alignment < sequence1.length-1)
				{
					alignment++;
					align_comparison.setText("RIGHT");	
					//CompSeq(currentChar,currentMatrix); // !!!!!!!! HMMM !!!!!!!!!
					new Thread
					(
							new Runnable()
					{
						//@Override
						public void run() 
						{	
							final String somevar = CompSeq(currentChar,currentMatrix); // !!!!!!!! HMMM !!!!!!!!!
							messagepass.post (new Runnable ()
							{
					            //@Override
					            public void run() 
					            {
					            	align_comparison.setText(somevar);
					            }
					         });
						}
					}).start();
					
					DispSeq();
					
				}
			}
		});

	} // Overwrite onCreate
	

	
	public class MyOnItemSelectedListener implements OnItemSelectedListener 
	{

	    public void onItemSelected(AdapterView<?> parent,View view, int pos, long id) 
	    {
	    	Toast.makeText(parent.getContext(), parent.getItemAtPosition(pos).toString()+ " selected.", Toast.LENGTH_LONG).show();
	    	switch(pos)
	    	{
		    case 0:
		    	currentChar = amino_alphabet45or80;
		    	currentMatrix = Blosum45;
		    	break;
		    case 1:
		    	currentChar = amino_alphabet62;
		    	currentMatrix = Blosum62;
		    	break;
		    case 2:
		    	currentChar = amino_alphabet45or80;
		    	currentMatrix = Blosum80;
		    	break;	
		    case 3:
		    	currentChar = DNA_alphabet;
		    	currentMatrix = DNAmat;
		    	break;	
		    case 4:
		    	currentChar = RNA_alphabet;
		    	currentMatrix = RNAmat;
		    	break;	
	    	}
	    }
	    
	    public void onNothingSelected(AdapterView parent) 
	    {
	      // Do nothing.
	    }

	}
	
	public void onNothingSelected(AdapterView parent) 
	{
	// Do nothing.
	}
	
	public void DispSeq()
	{

		String gap = "";
		for(int spaces = 0; spaces<Math.abs(alignment); spaces++)
		{
			gap += "#";
		}

		String sum1 = String.valueOf(sequence1);
		String sum2 = String.valueOf(sequence2);
		if(alignment<0)
		{
			sum2 = sum2 + gap;
			sum1 = gap + sum1;
		}
		else if(alignment>0)
		{
			sum2 = gap + sum2;
			sum1 = sum1 + gap;
		}
		tvSeq2.setText(sum2); // if it's 0, it'll print the normal way.
		tvSeq1.setText(sum1); 
	}
	
	public String CompSeq(char[] BLOSUMCHARS, int[][] BLOSUMSCORE){
		// set penalty for gaps left and right?
		AlignStrings();
		
		int seqlength1=sequence1.length;
		int seqlength2=sequence2.length;
		int matching = 0;
		int start = 0; // initial start and end comparison values set
		int end = seqlength1;
		int x_coord = 0; // need an error coordinate
		int y_coord = 0; // need an error coordinate, or adding in code checking text belongs to a BLOSUM matrix
		boolean pingx = true; // if the letters aren't in the BLOSUM MATRIX
		boolean pingy = true;
		if (alignment > 0) start = alignment; //only if we've moved the bottom string to the right should we move our start point.
		if (seqlength2+alignment < seqlength1)	end = seqlength2 + alignment;  // if the end of the second line is before the end of the first line, move the end point.
		
		// gap penalty

		//align_comparison.setText("" + end);
		for(int i=start; i<end; i++) //check if < end or <= end . Loop this as "bigger" because the sequences aren't of restricted size, so will save on running time with longer inputs than the BLOSUM matrices. Could optimise to check :/
		{
			//optimization lookup - go along, if you find one, stop for it, if the other one not, look from stopped to end.
			//could have had cleaner code with the Blosumchars as a string, or going String.ValueOf(BLOSUMCHARS).IndexOf(sequence1[i]), but didn't have time to work bugs out.
			for(int n=0; n<BLOSUMCHARS.length; n++) //check if < or <=
			{

				//align_comparison.setText(i + " " + n);
				if(sequence1[i]==BLOSUMCHARS[n]) // check alphabet changing <--- feed in?
				{
					x_coord = n;
					pingx = false;
				}
				if(sequence2[i-alignment]==BLOSUMCHARS[n]) // no point having two loops
				{
					y_coord = n;
					pingy = false;
				}
				
			}
			/*final String someothervar = "" + sequence1[i] + " " + pingx + " " + sequence2[i-alignment] + " " + pingy ;
	    	messagepass.post (new Runnable ()
			{
	            //@Override
	            public void run() 
	            {
	            	Toast.makeText(getApplicationContext(), someothervar, Toast.LENGTH_SHORT).show();
	            }
	         });*/
			if (pingx)
			{
				//Toast.makeText(getApplicationContext(), "Letter " + sequence1[i] + " doesn't exist in this comparison matrix.", Toast.LENGTH_LONG).show();
		    	final String somevar = "Letter " + sequence1[i] + " doesn't exist in this comparison matrix.";
		    	messagepass.post (new Runnable ()
				{
		            //@Override
		            public void run() 
		            {
		            	Toast.makeText(getApplicationContext(), somevar, Toast.LENGTH_LONG).show();
		            }
		         });
				return "Error";
		    	
				//error warning letter doesn't exist in matrix
				
			}
			else if (pingy)
			{
				//Toast.makeText(getApplicationContext(), "Letter " + sequence2[i] + " doesn't exist in this comparison matrix.", Toast.LENGTH_LONG).show();
				final String somevar = "Letter " + sequence2[i-alignment] + " doesn't exist in this comparison matrix.";
		    	messagepass.post (new Runnable ()
				{
		            //@Override
		            public void run() 
		            {
		            	Toast.makeText(getApplicationContext(), somevar, Toast.LENGTH_LONG).show();
		            }
		         });
				return "Error";
				//doesn't matter if they overwrite each other, there'll only be no error if all the letters are fixed.
			}
			else
			{
				matching += BLOSUMSCORE[x_coord][y_coord];
				pingx = true;
				pingy = true;
			}
		}// end character loop
		
		matching += gap_penalty*(Math.abs(seqlength2+alignment - seqlength1)+Math.abs(alignment)); // go a gap penalty for the sides - any overhang = penalty :/
				
		return "" + matching;
		
	}
	
	

	
	private void AlignStrings() 
	{
		
		
	}

	private void initialiseC() 
	{
		// TODO Auto-generated method stub
		Cmpr=(Button) findViewById(R.id.bCompare);
		left=(Button) findViewById(R.id.bleft);
		right=(Button) findViewById(R.id.bright);
		input1=(EditText) findViewById(R.id.Sequence1);
		input2=(EditText) findViewById(R.id.Sequence2);
		RES=(TextView) findViewById(R.id.tvResults);
		align_comparison = (TextView) findViewById(R.id.res);
		tvSeq1=(TextView) findViewById(R.id.tvSeq1);
		tvSeq2=(TextView) findViewById(R.id.tvSeq2);
		Matrices= (Spinner) findViewById(R.id.spinner1);
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
		this, R.array.BLOSUMS_ARRAY, android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		Matrices.setAdapter(adapter);
	}
} // End CompareSequenceActivity

		