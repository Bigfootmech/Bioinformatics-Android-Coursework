package com.example.EducationalApp;

import android.app.Activity;
import android.os.Bundle;

public class Process extends Activity{

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.process);
	}
}
