package com.example.EducationalApp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class Screen1 extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.screen1);
		Thread timer = new Thread()
		{
			public void run()
			{
				
				try
				{
					sleep(3000);
					
				} 
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
				finally
				{
					try{
						Class ourClass= Class.forName("com.example.EducationalApp.InputScreen");
						Intent ourIntent= new Intent(Screen1.this,ourClass);
						startActivity(ourIntent);
					}catch(ClassNotFoundException e){
						e.printStackTrace();
					}
        			
					//Intent openNew = new Intent("com.example.EducationalApp.Menu");
					//startActivity(openNew);
					
				}
			}
		};
		timer.start();	


	}
	@Override
	protected void onPause() {
		super.onPause();
		finish();
	}
}